#!/usr/bin/env python3

from menu import menu

user_choice = menu('a', 'b', 'c')

print(f'User chose {user_choice}')
